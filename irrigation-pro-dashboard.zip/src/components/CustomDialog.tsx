import { AlertTriangle, HelpCircle } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { DialogConfig } from "../types";

interface CustomDialogProps {
  config: DialogConfig;
  onClose: () => void;
}

export default function CustomDialog({ config, onClose }: CustomDialogProps) {
  const { isOpen, title, message, type, onConfirm, onCancel } = config;

  if (!isOpen) return null;

  const handleConfirm = () => {
    onClose();
    if (onConfirm) onConfirm();
  };

  const handleCancel = () => {
    onClose();
    if (onCancel) onCancel();
  };

  const isAlert = type === "warning" || type === "danger";

  return (
    <AnimatePresence>
      <div id="customDialog" className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm"
          onClick={handleCancel}
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 16 }}
          transition={{ type: "spring", duration: 0.4 }}
          className="bg-white w-full max-w-sm rounded-2xl shadow-2xl p-6 space-y-4 border border-slate-100 relative z-10"
        >
          <div className="flex items-start gap-3">
            <div
              id="dialogIconBox"
              className={`p-2.5 rounded-xl ${
                isAlert ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-600"
              }`}
            >
              {isAlert ? (
                <AlertTriangle className="w-6 h-6" />
              ) : (
                <HelpCircle className="w-6 h-6" />
              )}
            </div>
            <div>
              <h3 id="dialogTitle" className="text-base font-bold text-slate-800">
                {title}
              </h3>
              <p id="dialogMessage" className="text-xs text-slate-500 mt-1 leading-relaxed">
                {message}
              </p>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              id="dialogBtnCancel"
              type="button"
              onClick={handleCancel}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="dialogBtnConfirm"
              type="button"
              onClick={handleConfirm}
              className={`px-4 py-2 font-bold rounded-xl text-xs transition-colors shadow-sm cursor-pointer border-0 text-white ${
                isAlert
                  ? "bg-red-600 hover:bg-red-700 focus:ring-red-400"
                  : "bg-emerald-600 hover:bg-emerald-700 focus:ring-emerald-400"
              }`}
            >
              Confirm
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
