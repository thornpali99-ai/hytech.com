import { FormEvent, useEffect, useState } from "react";
import { Database, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { FirebaseConfig } from "../types";

interface DatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (config: FirebaseConfig) => void;
  onReset: () => void;
  currentConfig: FirebaseConfig;
  defaultConfig: FirebaseConfig;
}

export default function DatabaseModal({
  isOpen,
  onClose,
  onSave,
  onReset,
  currentConfig,
  defaultConfig,
}: DatabaseModalProps) {
  const [dbUrl, setDbUrl] = useState("");
  const [apiKey, setApiKey] = useState("");

  useEffect(() => {
    if (isOpen) {
      setDbUrl(currentConfig.databaseURL || "");
      setApiKey(currentConfig.apiKey || "");
    }
  }, [isOpen, currentConfig]);

  if (!isOpen) return null;

  const extractProjectId = (url: string) => {
    if (!url) return "weatherstation-c4dc5";
    try {
      const cleaned = url.replace("https://", "").replace("http://", "");
      const firstDot = cleaned.indexOf(".");
      if (firstDot !== -1) {
        return cleaned.substring(0, firstDot).replace("-default-rtdb", "");
      }
    } catch (e) {
      console.warn("Could not extract project name from url", e);
    }
    return "custom-project";
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const url = dbUrl.trim();
    const key = apiKey.trim();

    if (!url || !key) {
      alert("Please fill in both Database URL and API Key fields.");
      return;
    }

    const projId = extractProjectId(url);
    const newConfig: FirebaseConfig = {
      apiKey: key,
      authDomain: `${projId}.firebaseapp.com`,
      databaseURL: url,
      projectId: projId,
      storageBucket: `${projId}.firebasestorage.app`,
    };

    onSave(newConfig);
  };

  const handleReset = () => {
    setDbUrl(defaultConfig.databaseURL);
    setApiKey(defaultConfig.apiKey);
    onReset();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl relative z-10 border border-slate-100"
        >
          <div className="bg-slate-800 p-6 text-white flex justify-between items-center">
            <h3 className="font-bold flex items-center gap-2">
              <Database className="text-emerald-400 w-5 h-5 animate-pulse" /> Setup Active Firebase
            </h3>
            <button
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                Database URL Link
              </label>
              <input
                type="text"
                value={dbUrl}
                onChange={(e) => setDbUrl(e.target.value)}
                placeholder="https://your-project-default-rtdb.firebaseio.com"
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-mono"
                required
              />
            </div>
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                API Key Link
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIzaSyYourFirebaseWebApiKeyHere"
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-mono"
                required
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="flex-grow bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer border-0"
              >
                Apply Configuration
              </button>
              <button
                type="button"
                onClick={handleReset}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer border-0"
              >
                Reset Default
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
