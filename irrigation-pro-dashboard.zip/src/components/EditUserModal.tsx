import { FormEvent, useEffect, useState } from "react";
import { UserCog, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { UserAccount } from "../types";

interface EditUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (originalId: string, updatedId: string, account: UserAccount) => void;
  userId: string;
  userAccount: UserAccount | null;
}

export default function EditUserModal({
  isOpen,
  onClose,
  onSave,
  userId,
  userAccount,
}: EditUserModalProps) {
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"admin" | "operator">("operator");

  useEffect(() => {
    if (isOpen && userAccount) {
      setFullName(userAccount.fullName || "");
      setUsername(userId || "");
      setPassword(userAccount.password || "");
      setRole(userAccount.role || "operator");
    }
  }, [isOpen, userId, userAccount]);

  if (!isOpen || !userAccount) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const cleanFn = fullName.trim();
    const cleanId = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanFn || !cleanId || !cleanPass) {
      alert("Please ensure all fields are correctly populated.");
      return;
    }

    if (cleanId === "admin" && userId !== "admin") {
      alert("The username 'admin' is system-reserved.");
      return;
    }

    onSave(userId, cleanId, {
      fullName: cleanFn,
      password: cleanPass,
      role: role,
      status: userAccount.status, // Preserve account active/suspended status
    });
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl relative z-10 border border-slate-100"
        >
          <div className="bg-slate-800 p-6 text-white flex justify-between items-center">
            <h3 className="font-bold flex items-center gap-2">
              <UserCog className="text-emerald-400 w-5 h-5" /> Edit User Account
            </h3>
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. John Doe"
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-semibold"
                required
              />
            </div>

            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                User ID / Username
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g. operator12"
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-semibold"
                required
                disabled={userId === "admin"} // The root admin can't have their ID renamed
              />
            </div>

            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                Security Password
              </label>
              <input
                type="text"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-semibold"
                required
              />
            </div>

            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                Access Role
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as "admin" | "operator")}
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-semibold bg-white"
                disabled={userId === "admin"} // The root admin must stay role admin
              >
                <option value="operator">Operator (Dashboard Control Only)</option>
                <option value="admin">Administrator (Full Systems + Admin Panels)</option>
              </select>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="flex-grow bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer border-0"
              >
                Apply Edits
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
