import { useState, useEffect } from "react";
import {
  Sprout,
  Thermometer,
  Droplets,
  Sliders,
  LineChart as LineChartIcon,
  Calendar,
  Download,
  Loader2,
  RefreshCw,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import { TelemetryData, SettingsData, HistoricalRecord } from "../types";

interface DashboardViewProps {
  telemetry: TelemetryData | null;
  settings: SettingsData | null;
  onSaveSettings: (settings: SettingsData) => Promise<boolean>;
  currentPeriod: string;
  onPeriodChange: (period: string) => void;
  historyLogs: HistoricalRecord[];
  liveLogs: HistoricalRecord[];
  activeDate: string;
  onDateChange: (date: string) => void;
  isLoadingHistory: boolean;
  onTriggerDialog: (
    title: string,
    message: string,
    type: "info" | "warning" | "danger"
  ) => void;
  lastUpdatedTime: string;
}

export default function DashboardView({
  telemetry,
  settings,
  onSaveSettings,
  currentPeriod,
  onPeriodChange,
  historyLogs,
  liveLogs,
  activeDate,
  onDateChange,
  isLoadingHistory,
  onTriggerDialog,
  lastUpdatedTime,
}: DashboardViewProps) {
  // Local state for settings inputs so the user can type and configure them independently from the live database values
  const [soilON, setSoilON] = useState("50");
  const [soilOFF, setSoilOFF] = useState("65");
  const [pumpTime, setPumpTime] = useState("1");
  const [delayTime, setDelayTime] = useState("1");
  const [tempSet, setTempSet] = useState("35.0");
  const [sprayerTime, setSprayerTime] = useState("1");
  const [sprayerDelay, setSprayerDelay] = useState("1");
  const [isSyncing, setIsSyncing] = useState(false);

  // Sync settings when they are loaded/updated from the database
  useEffect(() => {
    if (settings) {
      setSoilON(String(settings.setON ?? 50));
      setSoilOFF(String(settings.setOFF ?? 65));
      setPumpTime(String(settings.pTime ?? 1));
      setDelayTime(String(settings.dTime ?? 1));
      setTempSet(String(settings.tempSet ?? 35.0));
      setSprayerTime(String(settings.sTime ?? 1));
      setSprayerDelay(String(settings.sdTime ?? 1));
    }
  }, [settings]);

  // Determine active chart dataset
  const activeDataset = currentPeriod === "live" ? liveLogs : historyLogs;

  const handleSaveSettings = async () => {
    setIsSyncing(true);
    const updatedSettings: SettingsData = {
      setON: parseInt(soilON) || 0,
      setOFF: parseInt(soilOFF) || 0,
      pTime: parseInt(pumpTime) || 0,
      dTime: parseInt(delayTime) || 0,
      tempSet: parseFloat(tempSet) || 0,
      sTime: parseInt(sprayerTime) || 0,
      sdTime: parseInt(sprayerDelay) || 0,
    };

    const success = await onSaveSettings(updatedSettings);
    if (success) {
      setTimeout(() => {
        setIsSyncing(false);
      }, 1000);
    } else {
      setIsSyncing(false);
      onTriggerDialog(
        "Save Failed",
        "Could not save operational settings. Confirm database permissions are active.",
        "warning"
      );
    }
  };

  const handleExportCSV = () => {
    if (activeDataset.length === 0) {
      onTriggerDialog(
        "No Data",
        "There are no telemetry record values within the selected range to compile.",
        "warning"
      );
      return;
    }

    let csvContent =
      "Timestamp (UTC/ISO),Time,Soil Moisture %,Temperature °C,Humidity %,Pump Status,Sprayer Status\n";

    activeDataset.forEach((d) => {
      let formattedDate = "N/A";
      if (d.iso) {
        try {
          const parsed = new Date(d.iso);
          if (!isNaN(parsed.getTime())) {
            formattedDate = parsed.toISOString().replace("T", " ").replace("Z", "");
          }
        } catch (e) {
          formattedDate = "N/A";
        }
      }
      csvContent += `${formattedDate},${d.t},${d.s}%,${d.te}°C,${d.h}%,${d.p || "OFF"},${d.sp || "OFF"}\n`;
    });

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `HyTech_Sensor_Export_${currentPeriod}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="viewDashboard" className="space-y-8 animate-fade-in text-slate-800">
      {/* 1st Row: Environmental Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Soil Moisture */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-blue-500 flex justify-between items-center transition-transform hover:translate-y-[-2px]">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Soil Moisture
            </p>
            <h3 id="valMoisture" className="text-3xl font-black text-slate-800 mt-1">
              {telemetry ? `${telemetry.soil.toFixed(1)}%` : "--%"}
            </h3>
          </div>
          <div className="p-3 bg-blue-50 rounded-xl">
            <Sprout className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        {/* Air Temperature */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-orange-500 flex justify-between items-center transition-transform hover:translate-y-[-2px]">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Air Temperature
            </p>
            <h3 id="valTemp" className="text-3xl font-black text-slate-800 mt-1">
              {telemetry ? `${telemetry.temp.toFixed(1)}°C` : "--°C"}
            </h3>
          </div>
          <div className="p-3 bg-orange-50 rounded-xl">
            <Thermometer className="w-8 h-8 text-orange-500" />
          </div>
        </div>

        {/* Air Humidity */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-indigo-500 flex justify-between items-center transition-transform hover:translate-y-[-2px]">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Air Humidity
            </p>
            <h3 id="valHum" className="text-3xl font-black text-slate-800 mt-1">
              {telemetry ? `${telemetry.hum.toFixed(1)}%` : "--%"}
            </h3>
          </div>
          <div className="p-3 bg-indigo-50 rounded-xl">
            <Droplets className="w-8 h-8 text-indigo-500" />
          </div>
        </div>

        {/* Pumps Status Grid */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-emerald-500 flex flex-col justify-center gap-2">
          <div className="flex justify-between items-center border-b border-slate-100 pb-2">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
              Water Pump
            </span>
            <span
              id="valPump"
              className={`text-xs font-bold uppercase transition-colors duration-200 ${
                telemetry?.pump === "ON" ? "text-blue-600 status-pulse" : "text-slate-400"
              }`}
            >
              {telemetry?.pump === "ON" ? "ACTIVE 💦" : "NOT ACTIVE"}
            </span>
          </div>
          <div className="flex justify-between items-center pt-1">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
              Sprayer Pump
            </span>
            <span
              id="valSprayer"
              className={`text-xs font-bold uppercase transition-colors duration-200 ${
                telemetry?.sprayer === "ON" ? "text-orange-600 status-pulse" : "text-slate-400"
              }`}
            >
              {telemetry?.sprayer === "ON" ? "SPRAYING 💨" : "NOT ACTIVE"}
            </span>
          </div>
        </div>
      </div>

      {/* 2nd Row: Setpoints and Graph */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Setpoint Configurations panel */}
        <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-6 h-fit">
          <h2 className="text-lg font-bold flex items-center gap-2 text-slate-800 border-b border-slate-100 pb-3">
            <Sliders className="w-5 h-5 text-emerald-600" /> System Configurations
          </h2>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                  Soil ON (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={soilON}
                  onChange={(e) => setSoilON(e.target.value)}
                  className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none font-semibold text-slate-700 bg-slate-50"
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                  Soil OFF (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={soilOFF}
                  onChange={(e) => setSoilOFF(e.target.value)}
                  className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none font-semibold text-slate-700 bg-slate-50"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-3">
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                  Pump Run (Min)
                </label>
                <input
                  type="number"
                  min="1"
                  value={pumpTime}
                  onChange={(e) => setPumpTime(e.target.value)}
                  className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none font-semibold text-slate-700 bg-slate-50"
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                  Pump Delay (Min)
                </label>
                <input
                  type="number"
                  min="0"
                  value={delayTime}
                  onChange={(e) => setDelayTime(e.target.value)}
                  className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none font-semibold text-slate-700 bg-slate-50"
                />
              </div>
            </div>

            <div className="border-t border-slate-100 pt-3 space-y-3">
              <div>
                <label className="text-[10px] font-black text-slate-600 uppercase block mb-1">
                  Sprayer Trigger Temp (°C)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={tempSet}
                  onChange={(e) => setTempSet(e.target.value)}
                  className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none font-semibold text-slate-700 bg-slate-50"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                    Spray Run (Min)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={sprayerTime}
                    onChange={(e) => setSprayerTime(e.target.value)}
                    className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none font-semibold text-slate-700 bg-slate-50"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                    Spray Delay (Min)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={sprayerDelay}
                    onChange={(e) => setSprayerDelay(e.target.value)}
                    className="w-full border rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 outline-none font-semibold text-slate-700 bg-slate-50"
                  />
                </div>
              </div>
            </div>

            <button
              id="btnSync"
              type="button"
              disabled={isSyncing}
              onClick={handleSaveSettings}
              className={`w-full text-white font-bold py-3 px-4 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer border-0 ${
                isSyncing
                  ? "bg-emerald-700 scale-[0.98]"
                  : "bg-emerald-600 hover:bg-emerald-700 hover:shadow-lg"
              }`}
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? "animate-spin" : ""}`} />
              {isSyncing ? "Saving Configuration..." : "Save Configurations"}
            </button>
          </div>
        </div>

        {/* Environmental Trends Graph Panel */}
        <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 lg:col-span-2 flex flex-col min-h-[520px]">
          <div className="flex flex-wrap justify-between items-center mb-4 gap-4">
            <div>
              <h2 className="text-lg font-bold flex items-center gap-2 text-slate-800">
                <LineChartIcon className="w-5 h-5 text-emerald-600" /> Environment Trends
              </h2>
              <p className="text-[10px] text-slate-400 uppercase font-black mt-1 tracking-wider">
                History & Live Data Operations
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div
                id="datePickerContainer"
                className={`flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-2 py-1.5 shadow-sm transition-opacity ${
                  currentPeriod === "all" || currentPeriod === "live"
                    ? "opacity-40 pointer-events-none"
                    : ""
                }`}
              >
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <input
                  type="date"
                  value={activeDate}
                  onChange={(e) => onDateChange(e.target.value)}
                  className="text-xs font-semibold text-slate-600 outline-none cursor-pointer bg-transparent border-0 p-0"
                />
              </div>
              <button
                id="btnExportCSV"
                onClick={handleExportCSV}
                className="flex items-center gap-1.5 bg-emerald-50 text-emerald-700 text-[10px] px-3.5 py-2 rounded-xl font-bold hover:bg-emerald-100 transition-colors border border-emerald-200 shadow-sm cursor-pointer"
                title="Download Excel CSV Sheet"
              >
                <Download className="w-3 h-3" /> EXPORT HISTORY
              </button>
            </div>
          </div>

          {/* Period selector tabs scroll container */}
          <div className="flex items-center gap-1 bg-slate-100 p-1.5 rounded-xl mb-6 overflow-x-auto no-scrollbar">
            {["live", "1D", "1W", "1M", "3M", "all"].map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => onPeriodChange(p)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer border-0 ${
                  currentPeriod === p
                    ? "bg-emerald-600 text-white shadow-sm"
                    : "text-slate-500 hover:text-emerald-600"
                }`}
              >
                {p === "all" ? "✨ ALL HISTORY" : p.toUpperCase()}
              </button>
            ))}
          </div>

          <div className="flex-grow w-full h-[320px] relative">
            {isLoadingHistory && (
              <div className="absolute inset-0 bg-white/70 z-10 flex items-center justify-center">
                <div className="flex flex-col items-center gap-2">
                  <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
                  <span className="text-xs font-bold text-slate-500">
                    Fetching Database History...
                  </span>
                </div>
              </div>
            )}

            {activeDataset.length === 0 ? (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
                <p className="text-slate-400 font-medium text-xs">
                  No historical measurements are currently loaded.
                </p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={activeDataset}
                  margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis
                    dataKey="t"
                    stroke="#94a3b8"
                    tick={{ fontSize: 9 }}
                    dy={5}
                    tickLine={false}
                  />
                  <YAxis
                    stroke="#94a3b8"
                    tick={{ fontSize: 9 }}
                    domain={[0, 100]}
                    tickLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(255, 255, 255, 0.95)",
                      borderRadius: "12px",
                      border: "1px solid #e2e8f0",
                      fontSize: "11px",
                      boxShadow: "0 4px 12px rbg(0,0,0,0.05)",
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    height={36}
                    iconSize={8}
                    wrapperStyle={{ fontSize: "10px", fontWeight: "bold" }}
                  />
                  <Line
                    type="monotone"
                    name="Soil Moisture %"
                    dataKey="s"
                    stroke="#3b82f6"
                    strokeWidth={2.5}
                    dot={activeDataset.length < 60 ? { r: 3 } : false}
                    activeDot={{ r: 5 }}
                  />
                  <Line
                    type="monotone"
                    name="Air Temp °C"
                    dataKey="te"
                    stroke="#f97316"
                    strokeWidth={2}
                    dot={activeDataset.length < 60 ? { r: 3 } : false}
                    activeDot={{ r: 5 }}
                  />
                  <Line
                    type="monotone"
                    name="Air Hum %"
                    dataKey="h"
                    stroke="#6366f1"
                    strokeWidth={2}
                    dot={activeDataset.length < 60 ? { r: 3 } : false}
                    activeDot={{ r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center text-slate-400 text-[10px]">
            <span id="dataInfo" className="font-semibold italic">
              {currentPeriod === "live"
                ? "Showing incoming telemetry feeds"
                : `Loaded ${activeDataset.length} logs for selection`}
            </span>
            <span
              id="valLastUpdate"
              className="px-2.5 py-1 bg-slate-100 rounded font-mono text-slate-500 font-semibold"
            >
              {lastUpdatedTime || "--:--:--"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
