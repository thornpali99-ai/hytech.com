import { FormEvent, useState } from "react";
import {
  Database,
  Users,
  UserPlus,
  ShieldAlert,
  X,
  Pencil,
  Trash2,
} from "lucide-react";
import { UserAccount, FirebaseConfig } from "../types";

interface AdminPanelViewProps {
  currentConfig: FirebaseConfig;
  onSaveCustomConfig: (config: FirebaseConfig) => void;
  onResetCustomConfig: () => void;
  users: Record<string, UserAccount>;
  onCreateUser: (username: string, account: UserAccount) => Promise<boolean>;
  onEditUserClick: (username: string, account: UserAccount) => void;
  onToggleUserStatus: (username: string, currentStatus: "Active" | "Suspended") => void;
  onDeleteUser: (username: string) => void;
  onTriggerDialog: (
    title: string,
    message: string,
    type: "info" | "warning" | "danger"
  ) => void;
}

export default function AdminPanelView({
  currentConfig,
  onSaveCustomConfig,
  onResetCustomConfig,
  users,
  onCreateUser,
  onEditUserClick,
  onToggleUserStatus,
  onDeleteUser,
  onTriggerDialog,
}: AdminPanelViewProps) {
  // DB Config state
  const [dbUrl, setDbUrl] = useState(currentConfig.databaseURL || "");
  const [apiKey, setApiKey] = useState(currentConfig.apiKey || "");

  // Create user state
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [newFullName, setNewFullName] = useState("");
  const [newUserId, setNewUserId] = useState("");
  const [newUserPass, setNewUserPass] = useState("");
  const [newUserRole, setNewUserRole] = useState<"admin" | "operator">("operator");

  const extractProjectId = (url: string) => {
    if (!url) return "weatherstation-c4dc5";
    try {
      const cleaned = url.replace("https://", "").replace("http://", "");
      const firstDot = cleaned.indexOf(".");
      if (firstDot !== -1) {
        return cleaned.substring(0, firstDot).replace("-default-rtdb", "");
      }
    } catch (e) {
      console.warn("Could not extract project ID from", url, e);
    }
    return "custom-project";
  };

  const handleSaveConfig = (e: FormEvent) => {
    e.preventDefault();
    const url = dbUrl.trim();
    const key = apiKey.trim();

    if (!url || !key) {
      onTriggerDialog(
        "Invalid Settings",
        "Please provide a valid Database URL and Web API Key to connect.",
        "warning"
      );
      return;
    }

    const projId = extractProjectId(url);
    const newConfig: FirebaseConfig = {
      apiKey: key,
      authDomain: `${projId}.firebaseapp.com`,
      databaseURL: url,
      projectId: projId,
      storageBucket: `${projId}.firebasestorage.app`,
    };

    onSaveCustomConfig(newConfig);
  };

  const handleCreateUser = async (e: FormEvent) => {
    e.preventDefault();
    const fn = newFullName.trim();
    const id = newUserId.trim().toLowerCase();
    const pass = newUserPass.trim();

    if (!fn || !id || !pass) {
      onTriggerDialog(
        "Validation Error",
        "Please fill out all required fields to authorize a user account.",
        "warning"
      );
      return;
    }

    if (id === "admin") {
      onTriggerDialog(
        "Operation Excluded",
        "The root account username 'admin' is system-reserved.",
        "warning"
      );
      return;
    }

    const success = await onCreateUser(id, {
      fullName: fn,
      password: pass,
      role: newUserRole,
      status: "Active",
    });

    if (success) {
      setNewFullName("");
      setNewUserId("");
      setNewUserPass("");
      setNewUserRole("operator");
      setIsAddingUser(false);
    }
  };

  return (
    <div id="viewAdmin" className="space-y-8 animate-fade-in text-slate-800">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Section: Custom Database configuration */}
        <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-6 lg:col-span-1 h-fit">
          <div className="border-b pb-4 border-slate-100">
            <h2 className="text-lg font-bold flex items-center gap-2 text-slate-800">
              <Database className="text-emerald-600 w-5 h-5 animate-pulse" />
              Custom Database Setup
            </h2>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              Configure your dashboard to sync with your hardware node's Firebase credentials.
            </p>
          </div>

          <form onSubmit={handleSaveConfig} className="space-y-4">
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                Firebase RTDB URL
              </label>
              <input
                type="text"
                value={dbUrl}
                onChange={(e) => setDbUrl(e.target.value)}
                placeholder="https://your-project-id.firebaseio.com"
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-mono bg-slate-50"
                required
              />
            </div>
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                Firebase Web API Key
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-mono bg-slate-50"
                required
              />
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                type="submit"
                className="flex-grow bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl transition-all shadow-md text-xs cursor-pointer border-0"
              >
                Connect Custom
              </button>
              <button
                type="button"
                onClick={onResetCustomConfig}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-3.5 py-2.5 rounded-xl transition-all text-xs cursor-pointer border-0"
                title="Reset Default Settings"
              >
                Restore Default
              </button>
            </div>
          </form>
        </div>

        {/* Right Section: Enterprise User Directory */}
        <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-6 lg:col-span-2">
          <div className="flex justify-between items-start border-b pb-4 border-slate-100 flex-wrap gap-4">
            <div>
              <h2 className="text-lg font-bold flex items-center gap-2 text-slate-800">
                <Users className="text-emerald-600 w-5 h-5" />
                User Directory
              </h2>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Manage system logins, access configurations, and permission credentials.
              </p>
            </div>
            {!isAddingUser && (
              <button
                type="button"
                onClick={() => setIsAddingUser(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer border-0"
              >
                <UserPlus className="w-4 h-4" /> Create Account
              </button>
            )}
          </div>

          {/* Account Registration Form drawer */}
          {isAddingUser && (
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-4 animate-fade-in">
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <h3 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-emerald-600 animate-bounce" />
                  Register New System User
                </h3>
                <button
                  type="button"
                  onClick={() => setIsAddingUser(false)}
                  className="text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateUser} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={newFullName}
                      onChange={(e) => setNewFullName(e.target.value)}
                      placeholder="e.g. John Doe"
                      className="w-full border rounded-xl px-3.5 py-2 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-semibold bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                      User ID / Username
                    </label>
                    <input
                      type="text"
                      value={newUserId}
                      onChange={(e) => setNewUserId(e.target.value)}
                      placeholder="e.g. operator12"
                      className="w-full border rounded-xl px-3.5 py-2 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-semibold bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                      Security Password
                    </label>
                    <input
                      type="password"
                      value={newUserPass}
                      onChange={(e) => setNewUserPass(e.target.value)}
                      placeholder="Enter password"
                      className="w-full border rounded-xl px-3.5 py-2 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-semibold bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                      Access Role
                    </label>
                    <select
                      value={newUserRole}
                      onChange={(e) => setNewUserRole(e.target.value as "admin" | "operator")}
                      className="w-full border rounded-xl px-3.5 py-2 text-xs focus:ring-2 focus:ring-emerald-500 outline-none font-semibold bg-white cursor-pointer"
                    >
                      <option value="operator">Operator (Dashboard Control Only)</option>
                      <option value="admin">Administrator (Full Systems + Admin Panels)</option>
                    </select>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="submit"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2 rounded-xl text-xs transition-all shadow-sm cursor-pointer border-0"
                  >
                    Authorize New Account
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* User Table container */}
          <div className="overflow-x-auto border border-slate-200 rounded-2xl bg-white shadow-inner">
            <table className="w-full border-collapse text-left text-xs text-slate-600">
              <thead className="bg-slate-50 font-bold uppercase text-slate-400 tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-4">Profile</th>
                  <th className="p-4">User ID</th>
                  <th className="p-4">Role</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody id="authorizedUsersList" className="divide-y divide-slate-100">
                {Object.keys(users).length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400 italic font-medium">
                      Syncing user directory...
                    </td>
                  </tr>
                ) : (
                  Object.keys(users).map((username) => {
                    const item = users[username];
                    const initials = (item.fullName || username).substring(0, 2).toUpperCase();

                    return (
                      <tr key={username} className="hover:bg-slate-50/50 transition-colors">
                        <td className="p-4 flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center font-bold text-xs uppercase border border-slate-200">
                            {initials}
                          </div>
                          <div>
                            <p className="font-bold text-slate-800 text-xs">
                              {item.fullName || "Anonymous"}
                            </p>
                            <p className="text-[10px] text-slate-400">Synced profile</p>
                          </div>
                        </td>
                        <td className="p-4 font-mono text-slate-700 font-bold">{username}</td>
                        <td className="p-4">
                          {item.role === "admin" ? (
                            <span className="bg-purple-50 text-purple-700 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-purple-100">
                              Administrator
                            </span>
                          ) : (
                            <span className="bg-blue-50 text-blue-700 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-blue-100">
                              Operator
                            </span>
                          )}
                        </td>
                        <td className="p-4">
                          {item.status === "Suspended" ? (
                            <span className="bg-red-50 text-red-700 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-red-100">
                              Suspended
                            </span>
                          ) : (
                            <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-100">
                              Active
                            </span>
                          )}
                        </td>
                        <td className="p-4 text-right space-x-2 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => onEditUserClick(username, item)}
                            className="bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-lg p-1.5 transition-all inline-flex cursor-pointer"
                            title="Edit Account Details"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onToggleUserStatus(username, item.status || "Active")}
                            className="text-xs font-semibold px-2 py-1.5 bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200 rounded-lg transition-all cursor-pointer"
                          >
                            Toggle Status
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteUser(username)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1.5 border border-transparent hover:border-red-100 rounded-lg transition-all inline-flex cursor-pointer"
                            title="Revoke and Erase Credentials"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
