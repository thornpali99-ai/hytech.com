export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  databaseURL: string;
  projectId: string;
  storageBucket: string;
}

export interface TelemetryData {
  soil: number;
  temp: number;
  hum: number;
  pump: string;       // "ON" or "OFF"
  sprayer: string;    // "ON" or "OFF"
}

export interface SettingsData {
  setON: number;      // Soil moisture percentage to turn on pump
  setOFF: number;     // Soil moisture percentage to turn off pump
  pTime: number;      // Pump run time (minutes)
  dTime: number;      // Pump delay time (minutes)
  tempSet: number;    // Sprayer target trigger temp (C)
  sTime: number;      // Sprayer run time (minutes)
  sdTime: number;     // Sprayer delay time (minutes)
}

export interface UserAccount {
  fullName: string;
  password?: string;   // Optional on client for extra safety, but provided in this RTDB structure
  role: "admin" | "operator";
  status: "Active" | "Suspended";
}

export interface HistoricalRecord {
  t: string;          // Formatted time string, e.g. "14:32:01" or "06-12 14:30"
  s: number;          // Soil Moisture %
  te: number;         // Air Temperature C
  h: number;          // Air Humidity %
  p: string;          // Pump Status ("ON"/"OFF")
  sp: string;         // Sprayer Status ("ON"/"OFF")
  iso: string;        // ISO timestamp link
  timeMs: number;     // Milliseconds timestamp for correct ordering
}

export interface DialogConfig {
  isOpen: boolean;
  title: string;
  message: string;
  type: "info" | "warning" | "danger";
  onConfirm: (() => void) | null;
  onCancel: (() => void) | null;
}
