/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, FormEvent } from "react";
import {
  Droplets,
  Database as DatabaseIcon,
  LogOut,
  Info,
  UserCheck2,
  Lock,
  User,
  AlertCircle,
} from "lucide-react";
import { getApps, initializeApp, deleteApp, getApp } from "firebase/app";
import { getDatabase, ref, onValue, set as dbSet, update as dbUpdate, get as dbGet, Database } from "firebase/database";
import { getAuth, signInAnonymously } from "firebase/auth";

import {
  FirebaseConfig,
  TelemetryData,
  SettingsData,
  UserAccount,
  HistoricalRecord,
  DialogConfig,
} from "./types";

import DatabaseModal from "./components/DatabaseModal";
import EditUserModal from "./components/EditUserModal";
import CustomDialog from "./components/CustomDialog";
import DashboardView from "./components/DashboardView";
import AdminPanelView from "./components/AdminPanelView";

// Default placeholder / default system fallback settings
const DEFAULT_FIREBASE_CONFIG: FirebaseConfig = {
  apiKey: "NON//",
  authDomain: "NON//",
  databaseURL: "NON//",
  projectId: "NON//",
  storageBucket: "NON//"
};

const INITIAL_MOCK_SETTINGS: SettingsData = {
  setON: 50,
  setOFF: 65,
  pTime: 2,
  dTime: 1,
  tempSet: 35.0,
  sTime: 1,
  sdTime: 1,
};

const INITIAL_MOCK_USERS: Record<string, UserAccount> = {
  "admin": { fullName: "System Admin", role: "admin", status: "Active", password: "x112233" },
  "operator1": { fullName: "Prasit Pali", role: "operator", status: "Active", password: "123" }
};

export default function App() {
  // Authentication & Layout Views State
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<"admin" | "operator">("operator");
  const [currentUser, setCurrentUser] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"dashboard" | "admin">("dashboard");

  // Login Form Input State
  const [loginId, setLoginId] = useState("");
  const [loginPass, setLoginPass] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);

  // Firebase configurations
  const [firebaseConfig, setFirebaseConfig] = useState<FirebaseConfig>(() => {
    const cached = localStorage.getItem("custom_firebase_config");
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        return DEFAULT_FIREBASE_CONFIG;
      }
    }
    return DEFAULT_FIREBASE_CONFIG;
  });

  const [dbInstance, setDbInstance] = useState<Database | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<"Offline" | "Simulating" | "Connected">("Offline");

  // Core Data States
  const [telemetry, setTelemetry] = useState<TelemetryData | null>(null);
  const [settings, setSettings] = useState<SettingsData | null>(null);
  const [users, setUsers] = useState<Record<string, UserAccount>>(INITIAL_MOCK_USERS);
  const [liveLogs, setLiveLogs] = useState<HistoricalRecord[]>([]);
  const [historyLogs, setHistoryLogs] = useState<HistoricalRecord[]>([]);
  const [activeFilterDate, setActiveFilterDate] = useState<string>(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  });

  // UI Control states
  const [isDbModalOpen, setIsDbModalOpen] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string>("");
  const [editingUserAccount, setEditingUserAccount] = useState<UserAccount | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string>("--:--:--");

  // Custom alert and confirmation dialog state
  const [dialogConfig, setDialogConfig] = useState<DialogConfig>({
    isOpen: false,
    title: "",
    message: "",
    type: "info",
    onConfirm: null,
    onCancel: null,
  });

  // Reference for current running parameters in simulated environment
  const simulatedPumpRef = useRef<"ON" | "OFF">("OFF");
  const simulatedSprayerRef = useRef<"ON" | "OFF">("OFF");
  const simulationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize Login persistence on initial render
  useEffect(() => {
    const persistedLogin = localStorage.getItem("isLoggedIn") === "true";
    const persistedRole = localStorage.getItem("userRole") as "admin" | "operator";
    const persistedUser = localStorage.getItem("currentUsername") || "";

    if (persistedLogin && persistedRole) {
      setIsLoggedIn(true);
      setUserRole(persistedRole);
      setCurrentUser(persistedUser);
    }
  }, []);

  // Sync / Boot Firebase dynamic connection
  useEffect(() => {
    let isMounted = true;

    // Check if configuration represents a real backend database URL configuration
    const isMock =
      !firebaseConfig.databaseURL ||
      firebaseConfig.databaseURL === "NON//" ||
      !firebaseConfig.apiKey ||
      firebaseConfig.apiKey === "NON//";

    if (isMock) {
      if (isMounted) {
        setConnectionStatus("Simulating");
        setDbInstance(null);
        startSimulation();
      }
      return;
    }

    // Stop simulator if it was active
    stopSimulation();
    setConnectionStatus("Offline");

    const initFirebase = async () => {
      try {
        // Clean up current existing apps
        if (getApps().length > 0) {
          await deleteApp(getApp());
        }

        const appInstance = initializeApp(firebaseConfig);
        const dbRef = getDatabase(appInstance);
        const fbAuth = getAuth(appInstance);

        await signInAnonymously(fbAuth);

        if (isMounted) {
          setDbInstance(dbRef);
          setConnectionStatus("Connected");
          setupRealtimeListeners(dbRef);
        }
      } catch (err) {
        console.error("Firebase connection bootstrap failed. Reverting to Simulation:", err);
        if (isMounted) {
          setConnectionStatus("Simulating");
          startSimulation();
        }
      }
    };

    initFirebase();

    return () => {
      isMounted = false;
      stopSimulation();
    };
  }, [firebaseConfig]);

  // Listener routines for real connected firebase db
  const setupRealtimeListeners = (rtdb: Database) => {
    // 1. Live Telemetry
    onValue(ref(rtdb, "hydroponic"), (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const mapped: TelemetryData = {
          soil: parseFloat(data.soil) || 0,
          temp: parseFloat(data.temp) || 0,
          hum: parseFloat(data.hum) || 0,
          pump: data.pump || "OFF",
          sprayer: data.sprayer || "OFF",
        };
        setTelemetry(mapped);
        setLastUpdatedTime(new Date().toLocaleTimeString());

        // Append to logs for real-time live graph
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
        setLiveLogs((prev) => {
          const updated = [
            ...prev,
            {
              t: timeStr,
              s: mapped.soil,
              te: mapped.temp,
              h: mapped.hum,
              p: mapped.pump,
              sp: mapped.sprayer,
              iso: now.toISOString(),
              timeMs: now.getTime(),
            },
          ];
          return updated.slice(-40); // Keep last 40 entries
        });
      }
    });

    // 2. Settings Synchronizers
    onValue(ref(rtdb, "settings"), (snapshot) => {
      const dbSettings = snapshot.val();
      if (dbSettings) {
        setSettings({
          setON: dbSettings.setON || 50,
          setOFF: dbSettings.setOFF || 65,
          pTime: dbSettings.pTime || 1,
          dTime: dbSettings.dTime || 1,
          tempSet: dbSettings.tempSet || 35.0,
          sTime: dbSettings.sTime || 1,
          sdTime: dbSettings.sdTime || 1,
        });
      }
    });

    // 3. Sync User Accounts List
    onValue(ref(rtdb, "authorized_users"), (snapshot) => {
      const dbUsers = snapshot.val();
      if (dbUsers) {
        setUsers(dbUsers);
      } else {
        // If empty on firebase, initialize with initial mock admin
        setUsers(INITIAL_MOCK_USERS);
        // Sync it to Firebase
        dbSet(ref(rtdb, "authorized_users"), INITIAL_MOCK_USERS);
      }
    });
  };

  // Run dynamic historical filters based on active selected period
  const fetchHistoricalData = async (period: string, dateStr: string) => {
    if (connectionStatus !== "Connected" || !dbInstance) {
      // Offline simulation fallback for historical data
      generateSimulationHistory(period, dateStr);
      return;
    }

    setIsLoadingHistory(true);
    const anchorDate = dateStr ? new Date(dateStr) : new Date();
    let startTime = 0;
    let endTime = 0;

    if (period === "1D") {
      const start = new Date(anchorDate);
      start.setHours(0, 0, 0, 0);
      startTime = start.getTime();

      const end = new Date(anchorDate);
      end.setHours(23, 59, 59, 999);
      endTime = end.getTime();
    } else if (period === "1W") {
      const end = new Date(anchorDate);
      end.setHours(23, 59, 59, 999);
      endTime = end.getTime();

      const start = new Date(anchorDate);
      start.setDate(start.getDate() - 7);
      start.setHours(0, 0, 0, 0);
      startTime = start.getTime();
    } else if (period === "1M") {
      const end = new Date(anchorDate);
      end.setHours(23, 59, 59, 999);
      endTime = end.getTime();

      const start = new Date(anchorDate);
      start.setDate(start.getDate() - 30);
      start.setHours(0, 0, 0, 0);
      startTime = start.getTime();
    } else if (period === "3M") {
      const end = new Date(anchorDate);
      end.setHours(23, 59, 59, 999);
      endTime = end.getTime();

      const start = new Date(anchorDate);
      start.setDate(start.getDate() - 90);
      start.setHours(0, 0, 0, 0);
      startTime = start.getTime();
    }

    try {
      const snapshot = await dbGet(ref(dbInstance, "history"));
      const records: HistoricalRecord[] = [];

      if (snapshot.exists()) {
        snapshot.forEach((child) => {
          const val = child.val();
          const key = child.key || "";

          // Parse timestamp key or fallback property
          let recordTimeMs = 0;
          let parsedDate = new Date(key);

          if (isNaN(parsedDate.getTime()) && val.iso) {
            parsedDate = new Date(val.iso);
          }

          if (!isNaN(parsedDate.getTime())) {
            recordTimeMs = parsedDate.getTime();
          } else {
            return; // Skip malformed rows
          }

          if (
            period === "all" ||
            (recordTimeMs >= startTime && recordTimeMs <= endTime)
          ) {
            let label = val.t;
            if (!label) {
              label =
                parsedDate.toLocaleDateString() +
                " " +
                parsedDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
            }

            records.push({
              t: label,
              s: val.s ?? val.soil ?? 0,
              te: val.te ?? val.temp ?? 0,
              h: val.h ?? val.hum ?? 0,
              p: val.p ?? val.pump ?? "OFF",
              sp: val.sp ?? val.sprayer ?? "OFF",
              iso: val.iso || key,
              timeMs: recordTimeMs,
            });
          }
        });
      }

      // Sort records strictly in chronological order
      records.sort((a, b) => a.timeMs - b.timeMs);
      setHistoryLogs(records);
    } catch (e) {
      console.error("Could not fetch database historical logs:", e);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  // Handle active historical periods toggling
  const [activePeriod, setActivePeriod] = useState("live");
  const handlePeriodChange = (period: string) => {
    setActivePeriod(period);
    if (period !== "live") {
      fetchHistoricalData(period, activeFilterDate);
    }
  };

  const handleDateChange = (date: string) => {
    setActiveFilterDate(date);
    if (activePeriod !== "live" && activePeriod !== "all") {
      fetchHistoricalData(activePeriod, date);
    }
  };

  // Simulated live telemetry stream loop
  const startSimulation = () => {
    setSettings(INITIAL_MOCK_SETTINGS);
    setTelemetry({
      soil: 54.0,
      temp: 32.5,
      hum: 64.0,
      pump: "OFF",
      sprayer: "OFF",
    });

    // Seed elegant initial historic chart records
    const today = new Date();
    const seeds: HistoricalRecord[] = [];
    for (let i = 24; i >= 0; i--) {
      const mockTime = new Date(today.getTime() - i * 60 * 60 * 1000);
      seeds.push({
        t: mockTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        s: 48 + Math.sin(i * 0.5) * 10 + Math.random() * 2,
        te: 29 + Math.cos(i * 0.4) * 4 + Math.random() * 1.5,
        h: 60 + Math.sin(i * 0.3) * 8 + Math.random() * 2,
        p: Math.random() > 0.8 ? "ON" : "OFF",
        sp: Math.random() > 0.9 ? "ON" : "OFF",
        iso: mockTime.toISOString(),
        timeMs: mockTime.getTime(),
      });
    }
    setLiveLogs(seeds);

    // Simulated interval logic
    simulationIntervalRef.current = setInterval(() => {
      setTelemetry((prev) => {
        if (!prev) return null;

        const currentSettings = settings || INITIAL_MOCK_SETTINGS;
        let nextSoil = prev.soil;
        let nextTemp = prev.temp;
        let nextHum = prev.hum;
        let pumpActive = prev.pump;
        let sprayerActive = prev.sprayer;

        // Pump State logic and Soil Moisty dynamics
        if (nextSoil <= currentSettings.setON) {
          pumpActive = "ON";
        } else if (nextSoil >= currentSettings.setOFF) {
          pumpActive = "OFF";
        }

        // Active Sprayer target temperature dynamics
        if (nextTemp >= currentSettings.tempSet) {
          sprayerActive = "ON";
        } else if (nextTemp < currentSettings.tempSet - 1.5) {
          sprayerActive = "OFF";
        }

        // Temperature adjustments
        if (sprayerActive === "ON") {
          nextTemp -= 0.15 + Math.random() * 0.05;
          nextHum += 0.2 + Math.random() * 0.1;
        } else {
          nextTemp += 0.05 + Math.sin(Date.now() / 100000) * 0.03;
          nextHum -= 0.04 + Math.random() * 0.02;
        }

        // Moisture adjustments
        if (pumpActive === "ON") {
          nextSoil += 0.4 + Math.random() * 0.1;
        } else {
          nextSoil -= 0.06 + Math.random() * 0.02;
        }

        // Clip parameters to boundaries
        nextSoil = Math.max(0, Math.min(100, nextSoil));
        nextTemp = Math.max(10, Math.min(50, nextTemp));
        nextHum = Math.max(20, Math.min(100, nextHum));

        setLastUpdatedTime(new Date().toLocaleTimeString());

        // Log reading
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });

        setLiveLogs((prevLogs) => {
          const updated = [
            ...prevLogs,
            {
              t: timeStr,
              s: nextSoil,
              te: nextTemp,
              h: nextHum,
              p: pumpActive,
              sp: sprayerActive,
              iso: now.toISOString(),
              timeMs: now.getTime(),
            },
          ];
          return updated.slice(-40);
        });

        return {
          soil: nextSoil,
          temp: nextTemp,
          hum: nextHum,
          pump: pumpActive,
          sprayer: sprayerActive,
        };
      });
    }, 2500);
  };

  const stopSimulation = () => {
    if (simulationIntervalRef.current) {
      clearInterval(simulationIntervalRef.current);
      simulationIntervalRef.current = null;
    }
  };

  const generateSimulationHistory = (period: string, dateStr: string) => {
    setIsLoadingHistory(true);
    setTimeout(() => {
      const anchor = dateStr ? new Date(dateStr) : new Date();
      let length = 24;
      let spacingHours = 1;

      if (period === "1W") {
        length = 28;
        spacingHours = 6;
      } else if (period === "1M") {
        length = 30;
        spacingHours = 24;
      } else if (period === "3M") {
        length = 45;
        spacingHours = 48;
      }

      const generated: HistoricalRecord[] = [];
      for (let i = length; i >= 0; i--) {
        const d = new Date(anchor.getTime() - i * spacingHours * 60 * 60 * 1000);
        generated.push({
          t:
            period === "1D"
              ? d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
              : `${d.getMonth() + 1}-${d.getDate()} ${d.getHours()}:00`,
          s: 50 + Math.sin(i * 0.4) * 8 + Math.random() * 3,
          te: 31 + Math.cos(i * 0.3) * 3 + Math.random() * 1.5,
          h: 64 + Math.sin(i * 0.2) * 10 + Math.random() * 2,
          p: Math.random() > 0.85 ? "ON" : "OFF",
          sp: Math.random() > 0.9 ? "ON" : "OFF",
          iso: d.toISOString(),
          timeMs: d.getTime(),
        });
      }

      setHistoryLogs(generated);
      setIsLoadingHistory(false);
    }, 400);
  };

  // Authenticate user form handler
  const handleLoginSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    const cleanId = loginId.trim();
    const cleanPass = loginPass.trim();

    if (!cleanId || !cleanPass) {
      setLoginError("Please enter your User ID and Security Password.");
      return;
    }

    // Direct root override fallback checks
    if (cleanId === "admin" && cleanPass === "x112233") {
      triggerLoginSuccess("admin", "admin");
      return;
    }

    // Local state checks or real firebase checks
    if (connectionStatus === "Connected" && dbInstance) {
      try {
        const snap = await dbGet(ref(dbInstance, `authorized_users/${cleanId.toLowerCase()}`));
        if (snap.exists()) {
          const profile: UserAccount = snap.val();
          if (profile && profile.password === cleanPass) {
            if (profile.status === "Suspended") {
              setLoginError("This user account is Suspended. Please contact System Admin.");
              return;
            }
            triggerLoginSuccess(profile.role, cleanId);
            return;
          }
        }
        setLoginError("Incorrect User ID or Password credentials.");
      } catch (err) {
        setLoginError("Authentication failure. Realtime database is unresponsive.");
      }
    } else {
      // Simulation mode login
      const localAccount = users[cleanId.toLowerCase()];
      if (localAccount && localAccount.password === cleanPass) {
        if (localAccount.status === "Suspended") {
          setLoginError("This user account is Suspended. Please contact System Admin.");
          return;
        }
        triggerLoginSuccess(localAccount.role, cleanId);
      } else {
        setLoginError("Incorrect User ID or Password.");
      }
    }
  };

  const triggerLoginSuccess = (role: "admin" | "operator", username: string) => {
    localStorage.setItem("isLoggedIn", "true");
    localStorage.setItem("userRole", role);
    localStorage.setItem("currentUsername", username);

    setIsLoggedIn(true);
    setUserRole(role);
    setCurrentUser(username);
    setLoginId("");
    setLoginPass("");
    setActiveTab("dashboard");
  };

  const handleLogout = () => {
    triggerDialog(
      "Confirm Logout",
      "Are you sure you want to end your current session?",
      "info",
      () => {
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userRole");
        localStorage.removeItem("currentUsername");

        setIsLoggedIn(false);
        setCurrentUser("");
        setUserRole("operator");
        setActiveTab("dashboard");
      }
    );
  };

  // Setpoint updates save routines
  const handleSaveSettings = async (updatedSettings: SettingsData): Promise<boolean> => {
    if (connectionStatus === "Connected" && dbInstance) {
      try {
        await dbUpdate(ref(dbInstance, "settings"), updatedSettings);
        return true;
      } catch (e) {
        console.error("Failed to commit parameters write to firebase:", e);
        return false;
      }
    } else {
      // Simulation update fallback
      setSettings(updatedSettings);
      return true;
    }
  };

  // User Administration Operations
  const handleCreateUser = async (username: string, account: UserAccount): Promise<boolean> => {
    const cleanUName = username.trim().toLowerCase();

    // Prevent duplicate entries
    if (users[cleanUName]) {
      triggerDialog(
        "Invalid ID",
        `Username '${cleanUName}' is already registered in the user directory.`,
        "warning"
      );
      return false;
    }

    if (connectionStatus === "Connected" && dbInstance) {
      try {
        await dbSet(ref(dbInstance, `authorized_users/${cleanUName}`), account);
        triggerDialog(
          "User Registered",
          `Successfully registered system account credentials for ${cleanUName}`,
          "info"
        );
        return true;
      } catch (err) {
        console.error("Authorized user creation failed on firebase: ", err);
        return false;
      }
    } else {
      // Simulated State User creation
      setUsers((prev) => ({
        ...prev,
        [cleanUName]: account,
      }));
      triggerDialog(
        "User Registered",
        `Successfully registered operator account credentials for ${cleanUName} (Simulated)`,
        "info"
      );
      return true;
    }
  };

  const handleEditUserClick = (username: string, account: UserAccount) => {
    setEditingUserId(username);
    setEditingUserAccount(account);
  };

  const handleSaveEditedUser = async (
    originalId: string,
    updatedId: string,
    account: UserAccount
  ) => {
    if (connectionStatus === "Connected" && dbInstance) {
      try {
        if (originalId !== updatedId) {
          // Username change requires moving database keys
          const checkSnap = await dbGet(ref(dbInstance, `authorized_users/${updatedId}`));
          if (checkSnap.exists()) {
            triggerDialog(
              "Conflicting Username",
              `The username ID '${updatedId}' is already registered to another operator.`,
              "warning"
            );
            return;
          }

          await dbSet(ref(dbInstance, `authorized_users/${updatedId}`), account);
          await dbSet(ref(dbInstance, `authorized_users/${originalId}`), null);
        } else {
          // Plain field updates
          await dbUpdate(ref(dbInstance, `authorized_users/${originalId}`), {
            fullName: account.fullName,
            password: account.password,
            role: account.role,
          });
        }

        setEditingUserAccount(null);
        setEditingUserId("");
        triggerDialog(
          "Update Completed",
          `User credentials updated successfully for ${updatedId}`,
          "info"
        );
      } catch (e) {
        console.error("Could not write edited user records to firebase:", e);
      }
    } else {
      // Local state renaming simulated fallback
      setUsers((prev) => {
        const copy = { ...prev };
        if (originalId !== updatedId) {
          if (copy[updatedId]) {
            triggerDialog(
              "Conflicting Username",
              `The username ID '${updatedId}' is already registered in this dashboard.`,
              "warning"
            );
            return prev;
          }
          delete copy[originalId];
        }
        copy[updatedId] = account;
        return copy;
      });

      setEditingUserAccount(null);
      setEditingUserId("");
      triggerDialog(
        "Update Completed",
        `User credentials updated successfully for ${updatedId} (Simulated)`,
        "info"
      );
    }
  };

  const handleToggleUserStatus = (username: string, currentStatus: "Active" | "Suspended") => {
    if (username === "admin") {
      triggerDialog(
        "Lock Protection",
        "The root administrator account cannot be suspended or locked.",
        "warning"
      );
      return;
    }

    const nextStatus = currentStatus === "Active" ? "Suspended" : "Active";

    triggerDialog(
      "Confirm Action",
      `Are you sure you want to change current permissions for '${username}' to [${nextStatus}]?`,
      "info",
      async () => {
        if (connectionStatus === "Connected" && dbInstance) {
          try {
            await dbUpdate(ref(dbInstance, `authorized_users/${username}`), {
              status: nextStatus,
            });
          } catch (e) {
            console.error("Error setting user active states: ", e);
          }
        } else {
          setUsers((prev) => {
            if (!prev[username]) return prev;
            return {
              ...prev,
              [username]: {
                ...prev[username],
                status: nextStatus,
              },
            };
          });
        }
      }
    );
  };

  const handleDeleteUser = (username: string) => {
    if (username === "admin") {
      triggerDialog(
        "Security Guard",
        "The root administrator ('admin') account cannot be deleted or pruned.",
        "warning"
      );
      return;
    }

    triggerDialog(
      "Confirm Erase",
      `Are you sure you want to permanently delete and revoke credentials for '${username}'? This cannot be undone.`,
      "danger",
      async () => {
        if (connectionStatus === "Connected" && dbInstance) {
          try {
            await dbSet(ref(dbInstance, `authorized_users/${username}`), null);
            triggerDialog("Trash Completed", `Successfully erased '${username}' profile.`, "info");
          } catch (e) {
            console.error("Erase operation failed on firebase:", e);
          }
        } else {
          setUsers((prev) => {
            const copy = { ...prev };
            delete copy[username];
            return copy;
          });
          triggerDialog(
            "Account Erased",
            `Successfully deleted and revoked credentials for '${username}' (Simulated)`,
            "info"
          );
        }
      }
    );
  };

  // Custom DB config save
  const handleSaveCustomConfig = (newConfig: FirebaseConfig) => {
    localStorage.setItem("custom_firebase_config", JSON.stringify(newConfig));
    setFirebaseConfig(newConfig);
    setIsDbModalOpen(false);
    triggerDialog(
      "Connection Applied",
      "Analyzing and connecting to custom Firebase Realtime Database parameters.",
      "info"
    );
  };

  const handleResetCustomConfig = () => {
    localStorage.removeItem("custom_firebase_config");
    setFirebaseConfig(DEFAULT_FIREBASE_CONFIG);
    setIsDbModalOpen(false);
    triggerDialog(
      "Configs Restored",
      "Erase custom configuration keys. Returning to standard HyTech simulation dashboard.",
      "info"
    );
  };

  // Dialog control triggers support utilities
  const triggerDialog = (
    title: string,
    message: string,
    type: "info" | "warning" | "danger" = "info",
    onConfirm: (() => void) | null = null,
    onCancel: (() => void) | null = null
  ) => {
    setDialogConfig({
      isOpen: true,
      title,
      message,
      type,
      onConfirm,
      onCancel,
    });
  };

  return (
    <div id="mainBody" className="min-h-screen bg-slate-50 text-slate-800 font-sans transition-all">
      {/* ================= LOGIN MASTER CONTAINER ================= */}
      {!isLoggedIn && (
        <div id="loginWrapper" className="flex items-center justify-center min-h-screen bg-slate-900 px-4 py-8">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-fade-in relative">
            <div className="bg-emerald-600 p-8 text-white text-center relative">
              <div className="inline-flex p-4.5 bg-emerald-500 rounded-2xl mb-4 shadow-inner">
                <Droplets className="w-10 h-10 animate-bounce" />
              </div>
              <h2 className="text-2xl font-black tracking-tight uppercase">HYTECH</h2>
              <p className="text-emerald-100 text-xs font-semibold uppercase tracking-wider mt-1.5 opacity-80">
                Green Irrigation Systems
              </p>

              <button
                type="button"
                id="btnOpenDbModalLogin"
                onClick={() => setIsDbModalOpen(true)}
                className="absolute top-5 right-5 text-emerald-100 hover:text-white p-2 rounded-xl hover:bg-emerald-700/60 transition-all cursor-pointer border-0 bg-transparent shadow"
                title="Database Configuration"
              >
                <DatabaseIcon className="w-4 h-4" />
              </button>
            </div>

            <form id="loginForm" onSubmit={handleLoginSubmit} className="p-8 space-y-6 bg-white">
              {loginError && (
                <div
                  id="loginError"
                  className="bg-red-50 text-red-600 text-xs font-bold p-3.5 rounded-xl border border-red-100 flex items-start gap-2.5"
                >
                  <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5 animate-pulse" />
                  <span>{loginError}</span>
                </div>
              )}
              <div className="space-y-4">
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input
                    id="loginId"
                    type="text"
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    placeholder="User ID / Username"
                    className="w-full border border-slate-200 pl-11 pr-4 py-3 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-medium text-sm bg-slate-50 text-slate-700"
                    required
                  />
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input
                    id="loginPass"
                    type="password"
                    value={loginPass}
                    onChange={(e) => setLoginPass(e.target.value)}
                    placeholder="Security Password"
                    className="w-full border border-slate-200 pl-11 pr-4 py-3 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-medium text-sm bg-slate-50 text-slate-700"
                    required
                  />
                </div>
              </div>
              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3.5 rounded-xl font-bold transition-all shadow-md active:scale-[0.99] cursor-pointer border-0 text-sm tracking-wide"
              >
                Login
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ================= DASHBOARD MASTER INTERFACE ================= */}
      {isLoggedIn && (
        <div id="dashboardWrapper" className="min-h-screen bg-slate-50 animate-fade-in flex flex-col">
          {/* Main navigation header */}
          <nav className="bg-emerald-600 text-white p-4 shadow-lg sticky top-0 z-40">
            <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-4">
              <div className="flex items-center gap-2">
                <Droplets className="w-7 h-7 text-emerald-100" />
                <h1 className="text-lg font-black tracking-wider uppercase">HYTECH CLOUD</h1>
              </div>

              <div className="flex items-center gap-4 flex-wrap">
                {/* Navigation Switches */}
                <div className="flex items-center bg-emerald-700 p-1 rounded-xl shadow-inner text-xs font-bold border border-emerald-800">
                  <button
                    type="button"
                    onClick={() => setActiveTab("dashboard")}
                    className={`px-4 py-2 rounded-lg transition-all border-0 font-bold text-xs cursor-pointer ${
                      activeTab === "dashboard" ? "bg-emerald-600 text-white shadow" : "text-emerald-100 hover:text-white"
                    }`}
                  >
                    DASHBOARD
                  </button>
                  {userRole === "admin" && (
                    <button
                      type="button"
                      onClick={() => setActiveTab("admin")}
                      className={`px-4 py-2 rounded-lg transition-all border-0 font-bold text-xs cursor-pointer ${
                        activeTab === "admin" ? "bg-emerald-600 text-white shadow" : "text-emerald-100 hover:text-white"
                      }`}
                    >
                      ADMIN PANEL
                    </button>
                  )}
                </div>

                <div
                  id="cloudStatus"
                  className="sm:flex items-center gap-1.5 bg-emerald-700/60 border border-emerald-800 px-3 py-1.5 rounded-full text-[10px] uppercase font-bold"
                >
                  <span
                    id="connIndicator"
                    className={`w-2 h-2 rounded-full status-pulse ${
                      connectionStatus === "Connected" ? "bg-emerald-400" : "bg-orange-400"
                    }`}
                  ></span>
                  <span id="connText">
                    {connectionStatus === "Connected" ? "Connected" : "Simulated"}
                  </span>
                </div>

                {/* Custom Db modal setups available for all logged-in roles */}
                <button
                  type="button"
                  onClick={() => setIsDbModalOpen(true)}
                  className="flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors shadow shadow-emerald-800/20 border-0 cursor-pointer text-white"
                  title="Configure Active Database"
                >
                  <DatabaseIcon className="w-3.5 h-3.5 text-emerald-300" />
                  DATABASE SETUP
                </button>

                <button
                  type="button"
                  id="btnLogout"
                  onClick={handleLogout}
                  className="flex items-center gap-1.5 bg-red-500 hover:bg-red-600 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow shadow-red-700/20 border-0 cursor-pointer text-white"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  LOGOUT
                </button>
              </div>
            </div>
          </nav>

          {/* Main workspace */}
          <main className="max-w-7xl mx-auto p-4 md:p-8 flex-grow w-full">
            {activeTab === "dashboard" ? (
              <DashboardView
                telemetry={telemetry}
                settings={settings}
                onSaveSettings={handleSaveSettings}
                currentPeriod={activePeriod}
                onPeriodChange={handlePeriodChange}
                historyLogs={historyLogs}
                liveLogs={liveLogs}
                activeDate={activeFilterDate}
                onDateChange={handleDateChange}
                isLoadingHistory={isLoadingHistory}
                onTriggerDialog={(t, m, ty) => triggerDialog(t, m, ty)}
                lastUpdatedTime={lastUpdatedTime}
              />
            ) : (
              <AdminPanelView
                currentConfig={firebaseConfig}
                onSaveCustomConfig={handleSaveCustomConfig}
                onResetCustomConfig={handleResetCustomConfig}
                users={users}
                onCreateUser={handleCreateUser}
                onEditUserClick={handleEditUserClick}
                onToggleUserStatus={handleToggleUserStatus}
                onDeleteUser={handleDeleteUser}
                onTriggerDialog={(t, m, ty) => triggerDialog(t, m, ty)}
              />
            )}

            {/* System Info / Footer concept */}
            <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm mt-8 transition-all">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                  <Info className="text-emerald-600 w-6 h-6 shrink-0" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 text-sm">System Intelligence</h3>
                  <p id="systemInsight" className="text-xs text-slate-400 mt-1.5 leading-relaxed font-semibold">
                    More Information Contact To Mr.PALI (0969809656){" "}
                    <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">
                      /HyTech
                    </span>...
                  </p>
                </div>
              </div>
            </div>
          </main>
        </div>
      )}

      {/* ================= ALL COMPODENT MODALS ================= */}
      <DatabaseModal
        isOpen={isDbModalOpen}
        onClose={() => setIsDbModalOpen(false)}
        onSave={handleSaveCustomConfig}
        onReset={handleResetCustomConfig}
        currentConfig={firebaseConfig}
        defaultConfig={DEFAULT_FIREBASE_CONFIG}
      />

      <EditUserModal
        isOpen={!!editingUserId}
        onClose={() => {
          setEditingUserId("");
          setEditingUserAccount(null);
        }}
        onSave={handleSaveEditedUser}
        userId={editingUserId}
        userAccount={editingUserAccount}
      />

      <CustomDialog config={dialogConfig} onClose={() => setDialogConfig((prev) => ({ ...prev, isOpen: false }))} />
    </div>
  );
}
